/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

define('streaming', ['hls', 'underscore'], function (Hls, _) {
            var Streaming = function () {
                        function Streaming(url, loadData) {
                                    _classCallCheck(this, Streaming);

                                    this.url = url;

                                    this.loadData = _.isUndefined(loadData) ? {
                                                fragsDataArr: [],
                                                startPosition: -1,
                                                lastError: {}
                                    } : loadData;

                                    this.fragData = null;
                                    this.fragsDataArr = this.loadData.fragsDataArr;
                                    this.fragsCount = 0;
                                    this.remove8BytesHeader = false;
                                    this.mediaErrorCount = 0;
                                    this.lastError = this.loadData.lastError;
                        }

                        _createClass(Streaming, [{
                                    key: 'run',
                                    value: function run() {
                                                var _this = this;

                                                if (!Hls.isSupported()) {
                                                            this.onErrorHandler && this.onErrorHandler();

                                                            return this;
                                                }

                                                if (this.hls) {
                                                            return this;
                                                }

                                                var hls = this.getHtl();

                                                hls.on(Hls.Events.MANIFEST_PARSED, this.manifestParsed.bind(this));

                                                hls.on(Hls.Events.BUFFER_CODECS, function (event, data) {
                                                            _this.remove8bytesheader = data.audio && data.audio.container === "audio/mp4";
                                                });

                                                hls.on(Hls.Events.BUFFER_APPENDING, function (event, data) {
                                                            _this.fragData = data.data;
                                                });

                                                hls.on(Hls.Events.FRAG_BUFFERED, this.fragBuffered.bind(this));

                                                hls.on(Hls.Events.ERROR, this.hlsError.bind(this));

                                                hls.loadSource(this.url);

                                                hls.attachMedia(this.getAudio());

                                                return this;
                                    }
                        }, {
                                    key: 'hlsError',
                                    value: function hlsError(event, data) {
                                                this.lastError = data;

                                                if (data.details === "bufferFullError" || data.details === "fragLoadError") {
                                                            this.clear();

                                                            this.loadData = {
                                                                        fragsDataArr: this.fragsDataArr.map(function (frag_arr) {
                                                                                    return frag_arr.slice();
                                                                        }),
                                                                        startPosition: this.getAudio().currentTime,
                                                                        lastError: this.lastError
                                                            };

                                                            return this.run();
                                                }

                                                if (data.type === Hls.ErrorTypes.MEDIA_ERROR && this.mediaErrorCount < 2) {
                                                            this.mediaErrorCount++;

                                                            if (this.mediaErrorCount > 1) {
                                                                        hls.swapAudioCodec();
                                                            }

                                                            hls.recoverMediaError();

                                                            return this;
                                                }

                                                this.clear();

                                                this.onErrorHandler && this.onErrorHandler();

                                                return this;
                                    }
                        }, {
                                    key: 'fragBuffered',
                                    value: function fragBuffered(event, data) {
                                                var _this2 = this;

                                                if (this.fragData) {
                                                            this.fragsDataArr.push(this.remove8BytesHeader ? this.fragData.slice(8, this.fragData.length) : this.fragData);
                                                }

                                                this.getAudio().currentTime = data.frag.start + data.frag.duration;

                                                var fragsSaved = this.fragsDataArr.length;

                                                this.onProgressHandler && this.onProgressHandler(Math.round(fragsSaved / this.fragsCount * 100));

                                                this.idleTimeout && clearTimeout(this.idleTimeout);
                                                this.idleTimeout = setTimeout(function () {
                                                            _this2.hlsError(null, _this2.lastError);
                                                }, 7000);

                                                if (fragsSaved >= this.fragsCount) {
                                                            var totalLength = this.fragsDataArr.reduce(function (prev, cur) {
                                                                        return prev + cur.length;
                                                            }, 0);

                                                            var totalData = new Uint8Array(totalLength);

                                                            var offset = 0;

                                                            this.fragsDataArr.forEach(function (element) {
                                                                        totalData.set(element, offset);
                                                                        offset += element.length;
                                                            });

                                                            this.clear();

                                                            this.onBufferHandler && this.onBufferHandler({ buffer: totalData, size: offset });
                                                }
                                    }
                        }, {
                                    key: 'manifestParsed',
                                    value: function manifestParsed(event, data) {
                                                this.fragsCount = data.levels[0].details.fragments.length;

                                                var path = data.levels[0].details.url.match(/^http.*\//);

                                                var size = 0;

                                                if (path) {
                                                            path = path[0];
                                                            for (var i = 0; i < this.fragsCount; i++) {
                                                                        if (!/^http/.test(data.levels[0].details.fragments[i].relurl)) {
                                                                                    data.levels[0].details.fragments[i].relurl = path + data.levels[0].details.fragments[i].relurl;
                                                                        }
                                                                        size += data.levels[0].details.fragments[i].loaded;
                                                            }
                                                }

                                                this.onStartHandler && this.onStartHandler();
                                    }
                        }, {
                                    key: 'clear',
                                    value: function clear() {
                                                this.getHtl().stopLoad();
                                                this.getHtl().destroy();

                                                this.hls = null;

                                                this.fragData = null;
                                                this.fragsDataArr = null;

                                                this.idleTimeout && clearTimeout(this.idleTimeout);
                                                this.idleTimeout = null;
                                    }
                        }, {
                                    key: 'getHtl',
                                    value: function getHtl() {
                                                if (!this.hls) {
                                                            this.hls = new Hls({
                                                                        enableWorker: false,
                                                                        defaultAudioCodec: 'mp3',
                                                                        startPosition: this.loadData.startPosition
                                                            });
                                                }

                                                return this.hls;
                                    }
                        }, {
                                    key: 'getAudio',
                                    value: function getAudio() {
                                                if (!this.audio) {
                                                            this.audio = document.createElement('audio');
                                                }

                                                return this.audio;
                                    }
                        }, {
                                    key: 'onStart',
                                    value: function onStart(callback) {
                                                this.onStartHandler = callback;

                                                return this;
                                    }
                        }, {
                                    key: 'onProgress',
                                    value: function onProgress(callback) {
                                                this.onProgressHandler = callback;

                                                return this;
                                    }
                        }, {
                                    key: 'onError',
                                    value: function onError(callback) {
                                                this.onErrorHandler = callback;

                                                return this;
                                    }
                        }, {
                                    key: 'onBuffer',
                                    value: function onBuffer(callback) {
                                                this.onBufferHandler = callback;

                                                return this;
                                    }
                        }]);

                        return Streaming;
            }();

            return Streaming;
});