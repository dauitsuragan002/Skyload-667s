/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

define('state_view', ['profile_view', 'backbone', 'underscore', 'jquery', 'common'], function (ProfileView, Backbone, _, $) {
    return Backbone.View.extend({
        tagName: 'div',
        className: 'l-state',
        template: _.template($('#template-state').html()),
        state: Application.POPUP_STATE_EMPTY,
        $content: null,
        profile: null,
        events: {
            'click .js-logo': 'goToSite',
            'click .js-menu-open': 'openMenu'
        },
        initialize: function initialize() {
            var _this = this;

            Application.App.on('profile_updated', function () {
                if (_this.state === Application.POPUP_STATE_SKYLOAD) {
                    _this.render();
                }
            });
        },
        render: function render(state) {
            var profile = Application.App.getProfile();

            if (!_.isUndefined(state)) {
                this.state = state;
            }

            this.$el.addClass('m-state-' + this.state).html(this.template());

            var args = { profile: profile, show_button: false };

            args.show_button = true;

            this.$content = this.$el.find('.js-state-content');
            this.$content.append(this.getTemplate()(args));

            if (this.state === Application.POPUP_STATE_SKYLOAD && profile.isLogin()) {
                this.profile = new ProfileView({ model: profile });

                this.$content.append(this.profile.render().el);
                this.$content.find('.js-profile-button').addClass('b-button b-button-blue b-button-selected b-button-long b-state__button');
            }

            return this;
        },
        getTemplate: function getTemplate() {
            return _.template($('#template-state-' + this.state).html());
        },
        openMenu: function openMenu() {
            Application.App.getMenu().open();
            return this;
        },
        goToSite: function goToSite() {
            Application.App.getMenu().goToSite();
        }
    });
});