/**
 * Skyload - Download manager for media content
 * @link http://skyload.io
 *
 * @version v7.4.0
 *
 * License Agreement:
 * http://skyload.io/eula
 *
 * Privacy Policy:
 * http://skyload.io/privacy-policy
 *
 * Support and FAQ:
 * http://skyload.io/help
 * skyload.extension@gmail.com
 */

"use strict";

define('checkbox_group_view', ['checkbox_view', 'common'], function (CheckBoxView) {
    return CheckBoxView.extend({
        initialize: function initialize() {
            var _this = this;

            this.setLabel(Application.getLocale('upload_to_sep_dir')).setTitle(Application.getLocale('to_sep_dir_des')).active(false);

            Application.App.getModel().on('change:separate_directory', function (model, value) {
                _this.active(value);
            });
        },
        onCheck: function onCheck() {
            Application.App.getModel().setSeparateDirectory(this.isChecked());
            return this;
        }
    });
});